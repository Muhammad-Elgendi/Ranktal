Selenium Standalone configured to run Chrome
