#!/usr/bin/env bash
#
# IMPORTANT: Change this file only in directory StandaloneDebug!

java ${JAVA_OPTS} -jar /opt/selenium/selenium-server-standalone.jar \
    ${SE_OPTS}
